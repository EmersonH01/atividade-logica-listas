package br.com.cruz.vita.exercicios.model;

import java.math.BigDecimal;

import lombok.Data;


@Data
public class CarroModel {

	private String nome ;
	private BigDecimal preco ;
		
}
