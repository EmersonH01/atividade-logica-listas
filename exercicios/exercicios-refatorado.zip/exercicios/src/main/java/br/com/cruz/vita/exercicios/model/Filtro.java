package br.com.cruz.vita.exercicios.model;

import lombok.Data;

@Data
public class Filtro {

	private String tipoFiltro;
	private String parametro;
	
}
